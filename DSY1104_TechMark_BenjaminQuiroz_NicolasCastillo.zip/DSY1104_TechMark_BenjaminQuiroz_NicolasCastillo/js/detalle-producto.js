// JavaScript para la página de detalle del producto
// Este archivo maneja la visualización del producto individual y productos relacionados

// Inicializar página de detalle
document.addEventListener('DOMContentLoaded', function() {
    if (document.getElementById('detalle-producto')) {
        cargarDetalleProducto();
        cargarProductosRelacionados();
        actualizarContadorCarrito();
    }
});

// Función para cargar el detalle del producto
function cargarDetalleProducto() {
    const urlParams = new URLSearchParams(window.location.search);
    const productoId = urlParams.get('id');
    
    if (!productoId) {
        mostrarError('Producto no encontrado');
        return;
    }
    
    const producto = obtenerProductoPorId(parseInt(productoId));
    if (!producto) {
        mostrarError('Producto no encontrado');
        return;
    }
    
    mostrarDetalleProducto(producto);
}

// Función para mostrar el detalle del producto
function mostrarDetalleProducto(producto) {
    const contenedor = document.getElementById('detalle-producto');
    if (!contenedor) return;
    
    contenedor.innerHTML = `
        <div class="col-md-6">
            <img src="${producto.imagen}" alt="${producto.nombre}" class="img-fluid rounded shadow"
                 onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
            <div class="producto-imagen" style="display: none; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; align-items: center; justify-content: center; min-height: 400px;">
                <i class="bi bi-box display-1"></i>
            </div>
        </div>
        <div class="col-md-6">
            <h1 class="display-5 mb-3">${producto.nombre}</h1>
            <p class="lead text-muted mb-4">${producto.descripcion}</p>
            
            <div class="producto-precio mb-4">
                <span class="h2 text-success">$${producto.precio.toFixed(2)}</span>
            </div>
            
            <div class="mb-4">
                <h5>Características:</h5>
                <ul class="list-unstyled">
                    <li><i class="bi bi-check-circle text-success me-2"></i>Garantía de 1 año</li>
                    <li><i class="bi bi-check-circle text-success me-2"></i>Envío gratis</li>
                    <li><i class="bi bi-check-circle text-success me-2"></i>Devolución en 30 días</li>
                    <li><i class="bi bi-check-circle text-success me-2"></i>Soporte técnico 24/7</li>
                </ul>
            </div>
            
            <div class="row mb-4">
                <div class="col-4">
                    <label for="cantidad" class="form-label">Cantidad:</label>
                    <select class="form-select" id="cantidad">
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                    </select>
                </div>
            </div>
            
            <div class="d-grid gap-2 d-md-block">
                <button class="btn btn-primary btn-lg me-2" onclick="agregarAlCarritoDesdeDetalle(${producto.id})">
                    <i class="bi bi-cart-plus"></i> Añadir al Carrito
                </button>
                <button class="btn btn-outline-secondary btn-lg" onclick="comprarAhora(${producto.id})">
                    <i class="bi bi-lightning"></i> Comprar Ahora
                </button>
            </div>
            
            <div class="mt-4">
                <a href="productos.html" class="btn btn-outline-primary">
                    <i class="bi bi-arrow-left"></i> Volver a Productos
                </a>
            </div>
        </div>
    `;
}

// Función para cargar productos relacionados
function cargarProductosRelacionados() {
    const contenedor = document.getElementById('productos-relacionados');
    if (!contenedor) return;
    
    const urlParams = new URLSearchParams(window.location.search);
    const productoId = parseInt(urlParams.get('id'));
    
    // Obtener productos excluyendo el actual
    const productos = obtenerProductos().filter(p => p.id !== productoId);
    const productosRelacionados = productos.slice(0, 3); // Mostrar solo 3 productos relacionados
    
    contenedor.innerHTML = '';
    
    productosRelacionados.forEach(producto => {
        const productoHTML = `
            <div class="col-md-4 mb-4">
                <div class="producto-card">
                    <img src="${producto.imagen}" alt="${producto.nombre}" class="producto-imagen" 
                         onerror="this.src='../img/placeholder.jpg'">
                    <h6>${producto.nombre}</h6>
                    <div class="producto-precio">$${producto.precio.toFixed(2)}</div>
                    <button class="btn btn-sm btn-primary w-100" onclick="verDetalleProducto(${producto.id})">
                        Ver Detalles
                    </button>
                </div>
            </div>
        `;
        contenedor.innerHTML += productoHTML;
    });
}

// Función para agregar al carrito desde el detalle
function agregarAlCarritoDesdeDetalle(productoId) {
    const cantidad = parseInt(document.getElementById('cantidad').value);
    const producto = obtenerProductoPorId(productoId);
    
    if (!producto) return;
    
    // Obtener carrito del localStorage
    let carrito = JSON.parse(localStorage.getItem('carrito')) || [];
    
    const itemExistente = carrito.find(item => item.id === productoId);
    
    if (itemExistente) {
        itemExistente.cantidad += cantidad;
    } else {
        carrito.push({
            ...producto,
            cantidad: cantidad
        });
    }
    
    // Guardar en localStorage
    localStorage.setItem('carrito', JSON.stringify(carrito));
    
    // Actualizar contador
    actualizarContadorCarrito();
    
    // Mostrar notificación
    mostrarNotificacion(`${cantidad} x ${producto.nombre} agregado al carrito`, 'success');
}

// Función para comprar ahora
function comprarAhora(productoId) {
    agregarAlCarritoDesdeDetalle(productoId);
    // Redirigir al carrito
    setTimeout(() => {
        window.location.href = 'carrito.html';
    }, 1000);
}

// Función para ver detalle de producto
function verDetalleProducto(productoId) {
    window.location.href = `detalle-producto.html?id=${productoId}`;
}

// Función para ver carrito
function verCarrito() {
    window.location.href = 'carrito.html';
}

// Función para actualizar contador del carrito
function actualizarContadorCarrito() {
    const contador = document.getElementById('carrito-count');
    if (contador) {
        const carrito = JSON.parse(localStorage.getItem('carrito')) || [];
        const totalItems = carrito.reduce((total, item) => total + item.cantidad, 0);
        contador.textContent = totalItems;
    }
}

// Función para mostrar notificaciones
function mostrarNotificacion(mensaje, tipo = 'info') {
    const notificacion = document.createElement('div');
    notificacion.className = `alert alert-${tipo} alert-dismissible fade show position-fixed`;
    notificacion.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    notificacion.innerHTML = `
        ${mensaje}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(notificacion);
    
    setTimeout(() => {
        if (notificacion.parentNode) {
            notificacion.parentNode.removeChild(notificacion);
        }
    }, 3000);
}

// Función para mostrar error
function mostrarError(mensaje) {
    const contenedor = document.getElementById('detalle-producto');
    if (contenedor) {
        contenedor.innerHTML = `
            <div class="col-12 text-center py-5">
                <h3 class="text-danger">${mensaje}</h3>
                <p class="text-muted">El producto que buscas no está disponible</p>
                <a href="productos.html" class="btn btn-primary">Ver Todos los Productos</a>
            </div>
        `;
    }
}
