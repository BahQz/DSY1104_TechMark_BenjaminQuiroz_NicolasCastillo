// JavaScript para el carrito de compras
// Este archivo maneja la funcionalidad del carrito usando localStorage

// Códigos de descuento disponibles
const codigosDescuento = {
    'BENI10': { descuento: 10, tipo: 'porcentaje', descripcion: '10% de descuento especial' }
};

// Variable para el código aplicado
let codigoAplicado = null;

// Inicializar carrito
document.addEventListener('DOMContentLoaded', function() {
    if (document.getElementById('items-carrito')) {
        cargarCarrito();
        actualizarContadorCarrito();
        configurarCodigoDescuento();
    }
});

// Función para cargar el carrito
function cargarCarrito() {
    const carrito = JSON.parse(localStorage.getItem('carrito')) || [];
    
    if (carrito.length === 0) {
        mostrarCarritoVacio();
    } else {
        mostrarItemsCarrito(carrito);
        mostrarResumenCarrito(carrito);
    }
}

// Función para mostrar carrito vacío
function mostrarCarritoVacio() {
    const contenedor = document.getElementById('items-carrito');
    if (!contenedor) return;
    
    contenedor.innerHTML = `
        <div class="text-center py-5">
            <i class="bi bi-cart-x display-1 text-muted"></i>
            <h3 class="mt-3">Tu carrito está vacío</h3>
            <p class="text-muted mb-4">Agrega algunos productos para comenzar tu compra</p>
            <a href="productos.html" class="btn btn-primary btn-lg">Ver Productos</a>
        </div>
    `;
    
    // Ocultar resumen si el carrito está vacío
    const resumen = document.getElementById('resumen-carrito');
    if (resumen) {
        resumen.innerHTML = '';
    }
}

// Función para mostrar items del carrito
function mostrarItemsCarrito(carrito) {
    const contenedor = document.getElementById('items-carrito');
    if (!contenedor) return;
    
    contenedor.innerHTML = '';
    
    carrito.forEach(item => {
        const itemHTML = `
            <div class="carrito-item">
                <div class="row align-items-center">
                    <div class="col-md-2">
                        <img src="${item.imagen}" alt="${item.nombre}" class="img-fluid rounded"
                             onerror="this.src='../img/placeholder.jpg'">
                    </div>
                    <div class="col-md-4">
                        <h6 class="mb-1">${item.nombre}</h6>
                        <p class="text-muted small mb-0">${item.descripcion}</p>
                    </div>
                    <div class="col-md-2">
                        <div class="input-group input-group-sm">
                            <button class="btn btn-outline-secondary" type="button" 
                                    onclick="actualizarCantidad(${item.id}, ${item.cantidad - 1})">-</button>
                            <input type="number" class="form-control text-center" value="${item.cantidad}" 
                                   min="1" max="10" onchange="actualizarCantidad(${item.id}, this.value)">
                            <button class="btn btn-outline-secondary" type="button" 
                                    onclick="actualizarCantidad(${item.id}, ${item.cantidad + 1})">+</button>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <span class="fw-bold">$${(item.precio * item.cantidad).toFixed(2)}</span>
                    </div>
                    <div class="col-md-2">
                        <button class="btn btn-outline-danger btn-sm" 
                                onclick="eliminarItem(${item.id})">
                            <i class="bi bi-trash"></i>
                        </button>
                    </div>
                </div>
            </div>
        `;
        contenedor.innerHTML += itemHTML;
    });
}

// Función para mostrar resumen del carrito
function mostrarResumenCarrito(carrito) {
    const contenedor = document.getElementById('resumen-carrito');
    if (!contenedor) return;
    
    const subtotal = carrito.reduce((total, item) => total + (item.precio * item.cantidad), 0);
    const envio = subtotal > 100 ? 0 : 15; // Envío gratis si el total es mayor a $100
    
    // Calcular descuento
    let descuento = 0;
    if (codigoAplicado) {
        const codigo = codigosDescuento[codigoAplicado];
        if (codigo) {
            if (codigo.tipo === 'porcentaje') {
                descuento = (subtotal * codigo.descuento) / 100;
            } else if (codigo.tipo === 'fijo') {
                if (codigoAplicado === 'FREESHIP') {
                    descuento = envio;
                } else {
                    descuento = codigo.descuento;
                }
            }
        }
    }
    
    const total = subtotal + envio - descuento;
    
    contenedor.innerHTML = `
        <div class="d-flex justify-content-between mb-2">
            <span>Subtotal:</span>
            <span>$${subtotal.toFixed(2)}</span>
        </div>
        <div class="d-flex justify-content-between mb-2">
            <span>Envío:</span>
            <span>${envio === 0 ? 'Gratis' : '$' + envio.toFixed(2)}</span>
        </div>
        ${descuento > 0 ? `
        <div class="d-flex justify-content-between mb-2 text-success">
            <span>Descuento (${codigoAplicado}):</span>
            <span>-$${descuento.toFixed(2)}</span>
        </div>
        ` : ''}
        <hr>
        <div class="d-flex justify-content-between carrito-total">
            <span>Total:</span>
            <span>$${total.toFixed(2)}</span>
        </div>
        ${envio === 0 ? '<small class="text-success">¡Envío gratis incluido!</small>' : ''}
        ${descuento > 0 ? '<small class="text-success">¡Descuento aplicado!</small>' : ''}
    `;
}

// Función para actualizar cantidad de un item
function actualizarCantidad(productoId, nuevaCantidad) {
    let carrito = JSON.parse(localStorage.getItem('carrito')) || [];
    
    const itemIndex = carrito.findIndex(item => item.id === productoId);
    
    if (itemIndex !== -1) {
        if (nuevaCantidad <= 0) {
            // Eliminar item si la cantidad es 0 o menor
            carrito.splice(itemIndex, 1);
        } else {
            // Actualizar cantidad
            carrito[itemIndex].cantidad = parseInt(nuevaCantidad);
        }
        
        // Guardar en localStorage
        localStorage.setItem('carrito', JSON.stringify(carrito));
        
        // Recargar carrito
        cargarCarrito();
        actualizarContadorCarrito();
    }
}

// Función para eliminar item del carrito
function eliminarItem(productoId) {
    let carrito = JSON.parse(localStorage.getItem('carrito')) || [];
    
    carrito = carrito.filter(item => item.id !== productoId);
    
    // Guardar en localStorage
    localStorage.setItem('carrito', JSON.stringify(carrito));
    
    // Recargar carrito
    cargarCarrito();
    actualizarContadorCarrito();
    
    // Mostrar notificación
    mostrarNotificacion('Producto eliminado del carrito', 'info');
}

// Función para proceder al pago
function procederPago() {
    const carrito = JSON.parse(localStorage.getItem('carrito')) || [];
    
    if (carrito.length === 0) {
        mostrarNotificacion('Tu carrito está vacío', 'warning');
        return;
    }
    
    // Simular proceso de pago
    mostrarNotificacion('Redirigiendo al proceso de pago...', 'info');
    
    // En una aplicación real, aquí se redirigiría a un procesador de pagos
    setTimeout(() => {
        alert('¡Gracias por tu compra! Este es un prototipo, por lo que no se procesará el pago real.');
        
        // Limpiar carrito después de la compra
        localStorage.removeItem('carrito');
        cargarCarrito();
        actualizarContadorCarrito();
    }, 2000);
}

// Función para actualizar contador del carrito
function actualizarContadorCarrito() {
    const contador = document.getElementById('carrito-count');
    if (contador) {
        const carrito = JSON.parse(localStorage.getItem('carrito')) || [];
        const totalItems = carrito.reduce((total, item) => total + item.cantidad, 0);
        contador.textContent = totalItems;
    }
}

// Función para mostrar notificaciones
function mostrarNotificacion(mensaje, tipo = 'info') {
    const notificacion = document.createElement('div');
    notificacion.className = `alert alert-${tipo} alert-dismissible fade show position-fixed`;
    notificacion.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    notificacion.innerHTML = `
        ${mensaje}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(notificacion);
    
    setTimeout(() => {
        if (notificacion.parentNode) {
            notificacion.parentNode.removeChild(notificacion);
        }
    }, 3000);
}

// Función para configurar el código de descuento
function configurarCodigoDescuento() {
    const formCodigo = document.getElementById('form-codigo-descuento');
    if (formCodigo) {
        formCodigo.addEventListener('submit', function(e) {
            e.preventDefault();
            const codigo = document.getElementById('codigo-descuento').value.trim().toUpperCase();
            aplicarCodigoDescuento(codigo);
        });
    }
}

// Función para aplicar código de descuento
function aplicarCodigoDescuento(codigo) {
    if (!codigo) {
        mostrarNotificacion('Por favor ingresa un código de descuento', 'warning');
        return;
    }
    
    if (codigosDescuento[codigo]) {
        codigoAplicado = codigo;
        const carrito = JSON.parse(localStorage.getItem('carrito')) || [];
        mostrarResumenCarrito(carrito);
        mostrarNotificacion(`¡Código ${codigo} aplicado! ${codigosDescuento[codigo].descripcion}`, 'success');
        
        // Actualizar el input para mostrar que está aplicado
        const inputCodigo = document.getElementById('codigo-descuento');
        if (inputCodigo) {
            inputCodigo.value = codigo;
            inputCodigo.classList.add('is-valid');
        }
    } else {
        mostrarNotificacion('Código de descuento no válido', 'danger');
    }
}

// Función para quitar código de descuento
function quitarCodigoDescuento() {
    codigoAplicado = null;
    const carrito = JSON.parse(localStorage.getItem('carrito')) || [];
    mostrarResumenCarrito(carrito);
    mostrarNotificacion('Código de descuento removido', 'info');
    
    // Limpiar el input
    const inputCodigo = document.getElementById('codigo-descuento');
    if (inputCodigo) {
        inputCodigo.value = '';
        inputCodigo.classList.remove('is-valid');
    }
}


// Función para ver carrito (navegación)
function verCarrito() {
    window.location.href = 'carrito.html';
}

