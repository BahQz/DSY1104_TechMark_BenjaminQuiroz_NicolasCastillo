// Configuración global para evitar vibraciones y mejorar estabilidad
// Este archivo se carga antes que main.js

// Configuración de rendimiento
window.addEventListener('load', function() {
    // Forzar repaint para estabilizar el layout
    document.body.style.transform = 'translateZ(0)';
    
    // Prevenir zoom en dispositivos móviles
    document.addEventListener('touchstart', function(e) {
        if (e.touches.length > 1) {
            e.preventDefault();
        }
    });
    
    // Prevenir scroll horizontal
    document.addEventListener('touchmove', function(e) {
        if (e.touches.length > 1) {
            e.preventDefault();
        }
    });
});

// Configuración de imágenes para evitar reflows
document.addEventListener('DOMContentLoaded', function() {
    // Prevenir carga de imágenes que no existen
    const images = document.querySelectorAll('img');
    images.forEach(img => {
        img.addEventListener('error', function() {
            this.style.display = 'none';
        });
        
        img.addEventListener('load', function() {
            this.style.opacity = '1';
        });
    });
});

// Configuración de navegación suave
document.addEventListener('DOMContentLoaded', function() {
    // Prevenir múltiples clics en enlaces
    const links = document.querySelectorAll('a[href]');
    links.forEach(link => {
        link.addEventListener('click', function(e) {
            // Prevenir navegación si ya se está navegando
            if (this.classList.contains('navigating')) {
                e.preventDefault();
                return;
            }
            
            this.classList.add('navigating');
            setTimeout(() => {
                this.classList.remove('navigating');
            }, 1000);
        });
    });
});

// Configuración de formularios para evitar saltos
document.addEventListener('DOMContentLoaded', function() {
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            // Prevenir múltiples envíos
            if (this.classList.contains('submitting')) {
                e.preventDefault();
                return;
            }
            
            this.classList.add('submitting');
            setTimeout(() => {
                this.classList.remove('submitting');
            }, 2000);
        });
    });
});

