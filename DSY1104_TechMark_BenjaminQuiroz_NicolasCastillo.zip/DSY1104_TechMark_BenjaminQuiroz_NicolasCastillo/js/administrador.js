// JavaScript para el panel de administración
// Este archivo maneja la funcionalidad del panel administrativo

// Inicializar panel de administración
document.addEventListener('DOMContentLoaded', function() {
    // Mostrar dashboard por defecto
    mostrarSeccion('dashboard');
    
    // Configurar formularios
    configurarFormulariosAdmin();
});

// Función para mostrar secciones del panel
function mostrarSeccion(seccion) {
    // Ocultar todas las secciones
    const secciones = document.querySelectorAll('.seccion-admin');
    secciones.forEach(seccion => {
        seccion.style.display = 'none';
    });
    
    // Mostrar la sección seleccionada
    const seccionSeleccionada = document.getElementById(seccion);
    if (seccionSeleccionada) {
        seccionSeleccionada.style.display = 'block';
    }
    
    // Actualizar menú activo
    const menuItems = document.querySelectorAll('.admin-menu a');
    menuItems.forEach(item => {
        item.classList.remove('active');
    });
    
    const itemActivo = document.querySelector(`[onclick="mostrarSeccion('${seccion}')"]`);
    if (itemActivo) {
        itemActivo.classList.add('active');
    }
}

// Función para configurar formularios del administrador
function configurarFormulariosAdmin() {
    // Configurar formularios de configuración
    const formulariosConfig = document.querySelectorAll('#configuracion form');
    formulariosConfig.forEach(form => {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            mostrarNotificacion('Configuración guardada correctamente', 'success');
        });
    });
}

// Función para mostrar formulario de nuevo usuario
function mostrarFormularioUsuario() {
    const modal = crearModal('Nuevo Usuario', `
        <form id="form-usuario">
            <div class="mb-3">
                <label class="form-label">Nombre Completo</label>
                <input type="text" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Email</label>
                <input type="email" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Rol</label>
                <select class="form-select" required>
                    <option value="">Seleccionar rol</option>
                    <option value="cliente">Cliente</option>
                    <option value="admin">Administrador</option>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Contraseña</label>
                <input type="password" class="form-control" required>
            </div>
        </form>
    `, 'Guardar', 'Cancelar', function() {
        mostrarNotificacion('Usuario creado correctamente', 'success');
    });
    
    document.body.appendChild(modal);
    const bsModal = new bootstrap.Modal(modal);
    bsModal.show();
}

// Función para mostrar formulario de nuevo producto
function mostrarFormularioProducto() {
    const modal = crearModal('Nuevo Producto', `
        <form id="form-producto">
            <div class="mb-3">
                <label class="form-label">Nombre del Producto</label>
                <input type="text" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Descripción</label>
                <textarea class="form-control" rows="3" required></textarea>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label class="form-label">Precio</label>
                        <input type="number" class="form-control" step="0.01" required>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label class="form-label">Stock</label>
                        <input type="number" class="form-control" required>
                    </div>
                </div>
            </div>
            <div class="mb-3">
                <label class="form-label">Imagen</label>
                <input type="file" class="form-control" accept="image/*">
            </div>
        </form>
    `, 'Guardar', 'Cancelar', function() {
        mostrarNotificacion('Producto creado correctamente', 'success');
    });
    
    document.body.appendChild(modal);
    const bsModal = new bootstrap.Modal(modal);
    bsModal.show();
}

// Función para mostrar formulario de nuevo artículo
function mostrarFormularioArticulo() {
    const modal = crearModal('Nuevo Artículo', `
        <form id="form-articulo">
            <div class="mb-3">
                <label class="form-label">Título</label>
                <input type="text" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Descripción</label>
                <textarea class="form-control" rows="3" required></textarea>
            </div>
            <div class="mb-3">
                <label class="form-label">Contenido</label>
                <textarea class="form-control" rows="5" required></textarea>
            </div>
            <div class="mb-3">
                <label class="form-label">Imagen</label>
                <input type="file" class="form-control" accept="image/*">
            </div>
        </form>
    `, 'Publicar', 'Cancelar', function() {
        mostrarNotificacion('Artículo publicado correctamente', 'success');
    });
    
    document.body.appendChild(modal);
    const bsModal = new bootstrap.Modal(modal);
    bsModal.show();
}

// Función para crear modal genérico
function crearModal(titulo, contenido, textoBoton, textoCancelar, callback) {
    const modal = document.createElement('div');
    modal.className = 'modal fade';
    modal.innerHTML = `
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">${titulo}</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    ${contenido}
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">${textoCancelar}</button>
                    <button type="button" class="btn btn-primary" onclick="ejecutarCallback()">${textoBoton}</button>
                </div>
            </div>
        </div>
    `;
    
    // Función global para ejecutar callback
    window.ejecutarCallback = function() {
        if (callback) {
            callback();
        }
        const bsModal = bootstrap.Modal.getInstance(modal);
        if (bsModal) {
            bsModal.hide();
        }
    };
    
    return modal;
}

// Función para cerrar sesión
function cerrarSesion() {
    if (confirm('¿Estás seguro de que quieres cerrar sesión?')) {
        mostrarNotificacion('Sesión cerrada correctamente', 'info');
        setTimeout(() => {
            window.location.href = '../index.html';
        }, 1500);
    }
}

// Función para mostrar notificaciones
function mostrarNotificacion(mensaje, tipo = 'info') {
    const notificacion = document.createElement('div');
    notificacion.className = `alert alert-${tipo} alert-dismissible fade show position-fixed`;
    notificacion.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    notificacion.innerHTML = `
        ${mensaje}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(notificacion);
    
    setTimeout(() => {
        if (notificacion.parentNode) {
            notificacion.parentNode.removeChild(notificacion);
        }
    }, 3000);
}

// Funciones de utilidad para el administrador
function actualizarEstadisticas() {
    // En una aplicación real, aquí se harían llamadas a la API para obtener estadísticas actualizadas
    console.log('Actualizando estadísticas...');
}

function exportarDatos(tipo) {
    mostrarNotificacion(`Exportando datos de ${tipo}...`, 'info');
    // En una aplicación real, aquí se generaría y descargaría el archivo
}

function realizarRespaldo() {
    if (confirm('¿Realizar respaldo de la base de datos?')) {
        mostrarNotificacion('Respaldo iniciado...', 'info');
        // En una aplicación real, aquí se ejecutaría el respaldo
    }
}

