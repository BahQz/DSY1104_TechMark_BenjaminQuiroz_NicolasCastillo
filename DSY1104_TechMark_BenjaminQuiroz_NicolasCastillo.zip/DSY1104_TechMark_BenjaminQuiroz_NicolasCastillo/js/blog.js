// JavaScript para el blog
// Este archivo maneja la funcionalidad del blog y artículos

// Inicializar blog
document.addEventListener('DOMContentLoaded', function() {
    // Cargar artículos en la página principal del blog
    if (document.getElementById('articulos-blog')) {
        cargarArticulosBlog();
        configurarNewsletter();
    }
    
    // Cargar detalle del artículo
    if (document.getElementById('contenido-articulo')) {
        cargarDetalleArticulo();
        cargarArticulosRelacionados();
    }
    
    // Actualizar contador del carrito
    actualizarContadorCarrito();
});

// Función para cargar artículos del blog
function cargarArticulosBlog() {
    const articulos = obtenerArticulos();
    const contenedor = document.getElementById('articulos-blog');
    if (!contenedor) return;
    
    contenedor.innerHTML = '';
    
    articulos.forEach(articulo => {
        const articuloHTML = `
            <div class="col-md-6 mb-4">
                <div class="articulo-card">
                    <img src="${articulo.imagen}" alt="${articulo.titulo}" class="articulo-imagen"
                         onerror="this.src='../img/placeholder.jpg'">
                    <div class="articulo-contenido">
                        <h5>${articulo.titulo}</h5>
                        <p class="text-muted small">${articulo.fecha}</p>
                        <p>${articulo.descripcion}</p>
                        <a href="detalle-articulo.html?id=${articulo.id}" class="btn btn-outline-primary">
                            Leer más
                        </a>
                    </div>
                </div>
            </div>
        `;
        contenedor.innerHTML += articuloHTML;
    });
}

// Función para cargar detalle del artículo
function cargarDetalleArticulo() {
    const urlParams = new URLSearchParams(window.location.search);
    const articuloId = urlParams.get('id');
    
    if (!articuloId) {
        mostrarErrorArticulo('Artículo no encontrado');
        return;
    }
    
    const articulo = obtenerArticuloPorId(parseInt(articuloId));
    if (!articulo) {
        mostrarErrorArticulo('Artículo no encontrado');
        return;
    }
    
    mostrarDetalleArticulo(articulo);
}

// Función para mostrar detalle del artículo
function mostrarDetalleArticulo(articulo) {
    const contenedor = document.getElementById('contenido-articulo');
    if (!contenedor) return;
    
    // Contenido extendido del artículo (simulado)
    const contenidoExtendido = generarContenidoExtendido(articulo);
    
    contenedor.innerHTML = `
        <article class="mb-5">
            <div class="mb-4">
                <img src="${articulo.imagen}" alt="${articulo.titulo}" class="img-fluid rounded shadow"
                     onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                <div class="articulo-imagen" style="display: none; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; align-items: center; justify-content: center; min-height: 300px; border-radius: 10px;">
                    <i class="bi bi-newspaper display-1"></i>
                </div>
            </div>
            
            <h1 class="display-5 mb-3">${articulo.titulo}</h1>
            <p class="text-muted mb-4">
                <i class="bi bi-calendar"></i> ${articulo.fecha} | 
                <i class="bi bi-person"></i> Por Admin | 
                <i class="bi bi-tag"></i> Tecnología
            </p>
            
            <div class="lead mb-4">
                ${articulo.descripcion}
            </div>
            
            <div class="contenido-articulo">
                ${contenidoExtendido}
            </div>
            
            <div class="mt-5">
                <a href="blog.html" class="btn btn-outline-primary">
                    <i class="bi bi-arrow-left"></i> Volver al Blog
                </a>
            </div>
        </article>
    `;
}

// Función para generar contenido extendido del artículo
function generarContenidoExtendido(articulo) {
    const contenidos = {
        1: `
            <p>En el mundo de la tecnología, 2025 promete ser un año lleno de innovaciones y avances que transformarán la forma en que vivimos y trabajamos. Desde la inteligencia artificial hasta la realidad virtual, las tendencias tecnológicas están evolucionando a un ritmo sin precedentes.</p>
            
            <h3>Inteligencia Artificial Generativa</h3>
            <p>La IA generativa continúa revolucionando múltiples industrias. Los modelos de lenguaje como GPT y otros sistemas de IA están mejorando constantemente, ofreciendo capacidades más sofisticadas para la creación de contenido, programación y análisis de datos.</p>
            
            <h3>Realidad Virtual y Aumentada</h3>
            <p>La RV y RA están ganando terreno en aplicaciones empresariales y de consumo. Desde entrenamiento corporativo hasta experiencias de entretenimiento inmersivas, estas tecnologías están redefiniendo la interacción digital.</p>
            
            <h3>Sostenibilidad Tecnológica</h3>
            <p>La conciencia ambiental está impulsando el desarrollo de tecnologías más eficientes y sostenibles. Las empresas están invirtiendo en soluciones que reducen el consumo energético y minimizan el impacto ambiental.</p>
            
            <blockquote class="blockquote">
                <p>"La tecnología debe servir para mejorar la vida de las personas y proteger nuestro planeta."</p>
                <footer class="blockquote-footer">Experto en Tecnología Sostenible</footer>
            </blockquote>
        `,
        2: `
            <p>Comprar online se ha convertido en una parte integral de nuestras vidas. Sin embargo, con la comodidad viene la responsabilidad de hacer compras seguras y inteligentes. Aquí te compartimos una guía completa para navegar el mundo del comercio electrónico.</p>
            
            <h3>Antes de Comprar</h3>
            <p>Investiga la reputación de la tienda online. Busca reseñas de otros clientes, verifica que tenga información de contacto clara y revisa sus políticas de devolución y garantía.</p>
            
            <h3>Seguridad en el Pago</h3>
            <p>Siempre verifica que el sitio web use conexiones seguras (HTTPS) y métodos de pago confiables. Evita realizar compras desde redes Wi-Fi públicas y considera usar tarjetas de crédito con protección contra fraudes.</p>
            
            <h3>Protección de Datos Personales</h3>
            <p>Lee cuidadosamente las políticas de privacidad y solo proporciona la información necesaria. Usa contraseñas fuertes y únicas para tus cuentas de compras online.</p>
            
            <h3>Después de la Compra</h3>
            <p>Guarda todos los comprobantes y confirmaciones de compra. Mantén un registro de tus compras y revisa regularmente los estados de cuenta de tus tarjetas.</p>
            
            <div class="alert alert-info">
                <h5>Consejo de Seguridad</h5>
                <p>Si algo parece demasiado bueno para ser verdad, probablemente lo sea. Desconfía de ofertas extremadamente atractivas de sitios desconocidos.</p>
            </div>
        `
    };
    
    return contenidos[articulo.id] || '<p>Contenido del artículo no disponible.</p>';
}

// Función para cargar artículos relacionados
function cargarArticulosRelacionados() {
    const contenedor = document.getElementById('articulos-relacionados');
    if (!contenedor) return;
    
    const urlParams = new URLSearchParams(window.location.search);
    const articuloId = parseInt(urlParams.get('id'));
    
    const articulos = obtenerArticulos().filter(a => a.id !== articuloId);
    const articulosRelacionados = articulos.slice(0, 3);
    
    contenedor.innerHTML = '';
    
    articulosRelacionados.forEach(articulo => {
        const articuloHTML = `
            <div class="mb-3">
                <div class="d-flex">
                    <img src="${articulo.imagen}" alt="${articulo.titulo}" 
                         class="img-thumbnail me-3" style="width: 80px; height: 80px; object-fit: cover;"
                         onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                    <div class="img-thumbnail me-3" style="width: 80px; height: 80px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; align-items: center; justify-content: center; display: none;">
                        <i class="bi bi-newspaper"></i>
                    </div>
                    <div>
                        <h6 class="mb-1">
                            <a href="detalle-articulo.html?id=${articulo.id}" class="text-decoration-none">
                                ${articulo.titulo}
                            </a>
                        </h6>
                        <small class="text-muted">${articulo.fecha}</small>
                    </div>
                </div>
            </div>
        `;
        contenedor.innerHTML += articuloHTML;
    });
}

// Función para configurar newsletter
function configurarNewsletter() {
    const formNewsletter = document.getElementById('form-newsletter');
    if (formNewsletter) {
        formNewsletter.addEventListener('submit', function(e) {
            e.preventDefault();
            const email = this.querySelector('input[type="email"]').value;
            
            if (email) {
                mostrarNotificacion('¡Gracias por suscribirte a nuestro newsletter!', 'success');
                this.reset();
            }
        });
    }
}

// Función para mostrar error de artículo
function mostrarErrorArticulo(mensaje) {
    const contenedor = document.getElementById('contenido-articulo');
    if (contenedor) {
        contenedor.innerHTML = `
            <div class="text-center py-5">
                <h3 class="text-danger">${mensaje}</h3>
                <p class="text-muted">El artículo que buscas no está disponible</p>
                <a href="blog.html" class="btn btn-primary">Volver al Blog</a>
            </div>
        `;
    }
}

// Función para actualizar contador del carrito
function actualizarContadorCarrito() {
    const contador = document.getElementById('carrito-count');
    if (contador) {
        const carrito = JSON.parse(localStorage.getItem('carrito')) || [];
        const totalItems = carrito.reduce((total, item) => total + item.cantidad, 0);
        contador.textContent = totalItems;
    }
}

// Función para mostrar notificaciones
function mostrarNotificacion(mensaje, tipo = 'info') {
    const notificacion = document.createElement('div');
    notificacion.className = `alert alert-${tipo} alert-dismissible fade show position-fixed`;
    notificacion.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    notificacion.innerHTML = `
        ${mensaje}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(notificacion);
    
    setTimeout(() => {
        if (notificacion.parentNode) {
            notificacion.parentNode.removeChild(notificacion);
        }
    }, 3000);
}

// Función para ver carrito
function verCarrito() {
    window.location.href = 'carrito.html';
}
