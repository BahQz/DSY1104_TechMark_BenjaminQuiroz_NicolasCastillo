// JavaScript principal para el E-Commerce
// Este archivo maneja la funcionalidad básica del sitio

// Datos de productos (simulando una base de datos)
const productos = [
    {
        id: 1,
        nombre: "Laptop Gaming",
        precio: 1299.99,
        imagen: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=400&h=300&fit=crop&crop=center",
        descripcion: "Laptop de alto rendimiento para gaming"
    },
    {
        id: 2,
        nombre: "Smartphone Pro",
        precio: 899.99,
        imagen: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400&h=300&fit=crop&crop=center",
        descripcion: "Smartphone con cámara profesional"
    },
    {
        id: 3,
        nombre: "Auriculares Wireless",
        precio: 199.99,
        imagen: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&h=300&fit=crop&crop=center",
        descripcion: "Auriculares inalámbricos con cancelación de ruido"
    },
    {
        id: 4,
        nombre: "Tablet 10 pulgadas",
        precio: 599.99,
        imagen: "https://images.unsplash.com/photo-1561154464-82e9adf32764?w=400&h=300&fit=crop&crop=center",
        descripcion: "Tablet perfecta para trabajo y entretenimiento"
    },
    {
        id: 5,
        nombre: "Smartwatch Deportivo",
        precio: 299.99,
        imagen: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&h=300&fit=crop&crop=center",
        descripcion: "Reloj inteligente con GPS y monitoreo de salud"
    },
    {
        id: 6,
        nombre: "Cámara DSLR",
        precio: 1599.99,
        imagen: "https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=400&h=300&fit=crop&crop=center",
        descripcion: "Cámara profesional para fotografía y video"
    }
];

// Datos de artículos del blog
const articulos = [
    {
        id: 1,
        titulo: "Las mejores tendencias tecnológicas 2025",
        imagen: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=800&h=400&fit=crop&crop=center",
        descripcion: "Descubre las innovaciones que marcarán el año en tecnología.",
        fecha: "15 de Enero, 2025"
    },
    {
        id: 2,
        titulo: "Guía completa para comprar online",
        imagen: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=800&h=400&fit=crop&crop=center",
        descripcion: "Consejos y trucos para hacer compras seguras en internet.",
        fecha: "10 de Enero, 2025"
    },
    {
        id: 3,
        titulo: "Inteligencia Artificial en el E-commerce",
        imagen: "https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=800&h=400&fit=crop&crop=center",
        descripcion: "Cómo la IA está revolucionando las compras online.",
        fecha: "8 de Enero, 2025"
    },
    {
        id: 4,
        titulo: "Sostenibilidad en el Comercio Digital",
        imagen: "https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?w=800&h=400&fit=crop&crop=center",
        descripcion: "Estrategias para un e-commerce más ecológico y responsable.",
        fecha: "5 de Enero, 2025"
    }
];

// Carrito de compras (usando localStorage)
let carrito = JSON.parse(localStorage.getItem('carrito')) || [];

// Variable para evitar múltiples inicializaciones
let paginaInicializada = false;

// Función para inicializar la página
document.addEventListener('DOMContentLoaded', function() {
    if (paginaInicializada) return;
    paginaInicializada = true;
    
    // Cargar productos destacados en la página principal
    if (document.getElementById('productos-destacados')) {
        cargarProductosDestacados();
    }
    
    // Cargar artículos del blog
    if (document.getElementById('articulos-blog')) {
        cargarArticulosBlog();
    }
    
    // Actualizar contador del carrito
    actualizarContadorCarrito();
    
    // Configurar formularios
    configurarFormularios();
});

// Función para cargar productos destacados
function cargarProductosDestacados() {
    const contenedor = document.getElementById('productos-destacados');
    if (!contenedor) return;
    
    contenedor.innerHTML = '';
    
    productos.forEach((producto, index) => {
        const productoHTML = `
            <div class="col-md-6 col-lg-3 mb-4">
                <div class="producto-card fade-in" style="animation-delay: ${index * 0.1}s">
                    <img src="${producto.imagen}" alt="${producto.nombre}" class="producto-imagen" 
                         onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                    <div class="producto-imagen" style="display: none;">
                        <i class="bi bi-box display-4 text-muted"></i>
                    </div>
                    <h5>${producto.nombre}</h5>
                    <p class="text-muted">${producto.descripcion}</p>
                    <div class="producto-precio">$${producto.precio.toFixed(2)}</div>
                    <button class="btn btn-primary w-100 mt-auto" onclick="agregarAlCarrito(${producto.id})">
                        Añadir al Carrito
                    </button>
                </div>
            </div>
        `;
        contenedor.innerHTML += productoHTML;
    });
}

// Función para cargar artículos del blog
function cargarArticulosBlog() {
    const contenedor = document.getElementById('articulos-blog');
    if (!contenedor) return;
    
    contenedor.innerHTML = '';
    
    articulos.forEach(articulo => {
        const articuloHTML = `
            <div class="col-md-6 mb-4">
                <div class="articulo-card">
                    <img src="${articulo.imagen}" alt="${articulo.titulo}" class="articulo-imagen"
                         onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                    <div class="articulo-imagen" style="display: none; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; align-items: center; justify-content: center;">
                        <i class="bi bi-newspaper display-4"></i>
                    </div>
                    <div class="articulo-contenido">
                        <h5>${articulo.titulo}</h5>
                        <p class="text-muted">${articulo.fecha}</p>
                        <p>${articulo.descripcion}</p>
                        <a href="pages/detalle-articulo.html?id=${articulo.id}" class="btn btn-outline-primary">
                            Leer más
                        </a>
                    </div>
                </div>
            </div>
        `;
        contenedor.innerHTML += articuloHTML;
    });
}

// Función para agregar producto al carrito
function agregarAlCarrito(productoId) {
    const producto = productos.find(p => p.id === productoId);
    if (!producto) return;
    
    const itemExistente = carrito.find(item => item.id === productoId);
    
    if (itemExistente) {
        itemExistente.cantidad += 1;
    } else {
        carrito.push({
            ...producto,
            cantidad: 1
        });
    }
    
    // Guardar en localStorage
    localStorage.setItem('carrito', JSON.stringify(carrito));
    
    // Actualizar contador
    actualizarContadorCarrito();
    
    // Mostrar notificación
    mostrarNotificacion(`${producto.nombre} agregado al carrito`, 'success');
}

// Función para actualizar contador del carrito
function actualizarContadorCarrito() {
    const contador = document.getElementById('carrito-count');
    if (contador) {
        const totalItems = carrito.reduce((total, item) => total + item.cantidad, 0);
        contador.textContent = totalItems;
    }
}

// Función para mostrar el carrito
function verCarrito() {
    // Navegación suave sin vibraciones
    const currentPath = window.location.pathname;
    const basePath = currentPath.includes('/pages/') ? '../' : '';
    window.location.href = `${basePath}pages/carrito.html`;
}

// Función para mostrar notificaciones
function mostrarNotificacion(mensaje, tipo = 'info') {
    // Crear elemento de notificación
    const notificacion = document.createElement('div');
    notificacion.className = `alert alert-${tipo} alert-dismissible fade show position-fixed`;
    notificacion.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    notificacion.innerHTML = `
        ${mensaje}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(notificacion);
    
    // Remover después de 3 segundos
    setTimeout(() => {
        if (notificacion.parentNode) {
            notificacion.parentNode.removeChild(notificacion);
        }
    }, 3000);
}

// Función para configurar formularios
function configurarFormularios() {
    // Configurar formulario de registro
    const formRegistro = document.getElementById('form-registro');
    if (formRegistro) {
        formRegistro.addEventListener('submit', validarRegistro);
    }
    
    // Configurar formulario de login
    const formLogin = document.getElementById('form-login');
    if (formLogin) {
        formLogin.addEventListener('submit', validarLogin);
    }
    
    // Configurar formulario de contacto
    const formContacto = document.getElementById('form-contacto');
    if (formContacto) {
        formContacto.addEventListener('submit', validarContacto);
    }
}

// Validación del formulario de registro
function validarRegistro(e) {
    e.preventDefault();
    
    const nombre = document.getElementById('nombre').value.trim();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;
    const confirmarPassword = document.getElementById('confirmar-password').value;
    
    let errores = [];
    
    // Validar nombre
    if (nombre.length < 2) {
        errores.push('El nombre debe tener al menos 2 caracteres');
    }
    
    // Validar email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        errores.push('Ingrese un email válido');
    }
    
    // Validar contraseña
    if (password.length < 4 || password.length > 10) {
        errores.push('La contraseña debe tener entre 4 y 10 caracteres');
    }
    
    // Validar confirmación de contraseña
    if (password !== confirmarPassword) {
        errores.push('Las contraseñas no coinciden');
    }
    
    if (errores.length > 0) {
        mostrarErrores(errores);
    } else {
        mostrarNotificacion('Registro exitoso', 'success');
        // Aquí se enviarían los datos al servidor
    }
}

// Validación del formulario de login
function validarLogin(e) {
    e.preventDefault();
    
    const email = document.getElementById('email-login').value.trim();
    const password = document.getElementById('password-login').value;
    
    let errores = [];
    
    // Validar email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        errores.push('Ingrese un email válido');
    }
    
    // Validar contraseña
    if (password.length < 4 || password.length > 10) {
        errores.push('La contraseña debe tener entre 4 y 10 caracteres');
    }
    
    if (errores.length > 0) {
        mostrarErrores(errores);
    } else {
        mostrarNotificacion('Login exitoso', 'success');
        // Aquí se validarían las credenciales con el servidor
    }
}

// Validación del formulario de contacto
function validarContacto(e) {
    e.preventDefault();
    
    const nombre = document.getElementById('nombre-contacto').value.trim();
    const email = document.getElementById('email-contacto').value.trim();
    const comentario = document.getElementById('comentario').value.trim();
    
    let errores = [];
    
    // Validar nombre
    if (nombre.length < 2) {
        errores.push('El nombre debe tener al menos 2 caracteres');
    }
    
    // Validar email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        errores.push('Ingrese un email válido');
    }
    
    // Validar comentario
    if (comentario.length < 10) {
        errores.push('El comentario debe tener al menos 10 caracteres');
    }
    
    if (errores.length > 0) {
        mostrarErrores(errores);
    } else {
        mostrarNotificacion('Mensaje enviado correctamente', 'success');
        // Aquí se enviaría el mensaje al servidor
    }
}

// Función para mostrar errores
function mostrarErrores(errores) {
    const contenedorErrores = document.getElementById('errores');
    if (contenedorErrores) {
        contenedorErrores.innerHTML = '';
        errores.forEach(error => {
            const div = document.createElement('div');
            div.className = 'alert alert-danger';
            div.textContent = error;
            contenedorErrores.appendChild(div);
        });
    }
}

// Función para obtener productos (para otras páginas)
function obtenerProductos() {
    return productos;
}

// Función para obtener un producto por ID
function obtenerProductoPorId(id) {
    return productos.find(p => p.id === parseInt(id));
}

// Función para obtener artículos del blog
function obtenerArticulos() {
    return articulos;
}

// Función para obtener un artículo por ID
function obtenerArticuloPorId(id) {
    return articulos.find(a => a.id === parseInt(id));
}
