// JavaScript específico para la página de productos
// Este archivo maneja la funcionalidad de búsqueda, filtrado y navegación de productos

// Variables globales
let productosFiltrados = [];
let terminoBusqueda = '';

// Inicializar página de productos
document.addEventListener('DOMContentLoaded', function() {
    if (document.getElementById('lista-productos')) {
        cargarProductos();
        configurarEventos();
    }
});

// Función para cargar todos los productos
function cargarProductos() {
    const productos = obtenerProductos();
    productosFiltrados = [...productos];
    mostrarProductos(productosFiltrados);
}

// Función para mostrar productos en la página
function mostrarProductos(productos) {
    const contenedor = document.getElementById('lista-productos');
    if (!contenedor) return;
    
    contenedor.innerHTML = '';
    
    if (productos.length === 0) {
        contenedor.innerHTML = `
            <div class="col-12 text-center py-5">
                <h3>No se encontraron productos</h3>
                <p class="text-muted">Intenta con otros términos de búsqueda o filtros</p>
            </div>
        `;
        return;
    }
    
    productos.forEach(producto => {
        const productoHTML = `
            <div class="col-md-6 col-lg-4 mb-4">
                <div class="producto-card fade-in">
                    <img src="${producto.imagen}" alt="${producto.nombre}" class="producto-imagen" 
                         onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                    <div class="producto-imagen" style="display: none;">
                        <i class="bi bi-box display-4 text-muted"></i>
                    </div>
                    <h5>${producto.nombre}</h5>
                    <p class="text-muted">${producto.descripcion}</p>
                    <div class="producto-precio">$${producto.precio.toFixed(2)}</div>
                    <div class="d-grid gap-2">
                        <button class="btn btn-primary" onclick="agregarAlCarrito(${producto.id})">
                            Añadir al Carrito
                        </button>
                        <button class="btn btn-outline-secondary" onclick="verDetalleProducto(${producto.id})">
                            Ver Detalles
                        </button>
                    </div>
                </div>
            </div>
        `;
        contenedor.innerHTML += productoHTML;
    });
}

// Función para configurar eventos
function configurarEventos() {
    // Evento de búsqueda en tiempo real
    const inputBusqueda = document.getElementById('busqueda-productos');
    if (inputBusqueda) {
        inputBusqueda.addEventListener('input', function() {
            terminoBusqueda = this.value.toLowerCase();
            filtrarProductos();
        });
    }
}

// Función para buscar productos
function buscarProductos() {
    const inputBusqueda = document.getElementById('busqueda-productos');
    if (inputBusqueda) {
        terminoBusqueda = inputBusqueda.value.toLowerCase();
        filtrarProductos();
    }
}

// Función para filtrar productos
function filtrarProductos() {
    const productos = obtenerProductos();
    let filtrados = [...productos];
    
    // Filtro por término de búsqueda
    if (terminoBusqueda) {
        filtrados = filtrados.filter(producto => 
            producto.nombre.toLowerCase().includes(terminoBusqueda) ||
            producto.descripcion.toLowerCase().includes(terminoBusqueda)
        );
    }
    
    // Filtro por precio
    const filtroPrecio = document.getElementById('filtro-precio').value;
    if (filtroPrecio) {
        filtrados = filtrados.filter(producto => {
            switch (filtroPrecio) {
                case '0-500':
                    return producto.precio >= 0 && producto.precio <= 500;
                case '500-1000':
                    return producto.precio > 500 && producto.precio <= 1000;
                case '1000+':
                    return producto.precio > 1000;
                default:
                    return true;
            }
        });
    }
    
    productosFiltrados = filtrados;
    mostrarProductos(productosFiltrados);
}

// Función para filtrar por precio
function filtrarPorPrecio() {
    filtrarProductos();
}

// Función para ver detalle de producto
function verDetalleProducto(productoId) {
    window.location.href = `detalle-producto.html?id=${productoId}`;
}

// Función para agregar al carrito (reutilizada de main.js)
function agregarAlCarrito(productoId) {
    const producto = obtenerProductoPorId(productoId);
    if (!producto) return;
    
    // Obtener carrito del localStorage
    let carrito = JSON.parse(localStorage.getItem('carrito')) || [];
    
    const itemExistente = carrito.find(item => item.id === productoId);
    
    if (itemExistente) {
        itemExistente.cantidad += 1;
    } else {
        carrito.push({
            ...producto,
            cantidad: 1
        });
    }
    
    // Guardar en localStorage
    localStorage.setItem('carrito', JSON.stringify(carrito));
    
    // Actualizar contador
    actualizarContadorCarrito();
    
    // Mostrar notificación
    mostrarNotificacion(`${producto.nombre} agregado al carrito`, 'success');
}

// Función para actualizar contador del carrito
function actualizarContadorCarrito() {
    const contador = document.getElementById('carrito-count');
    if (contador) {
        const carrito = JSON.parse(localStorage.getItem('carrito')) || [];
        const totalItems = carrito.reduce((total, item) => total + item.cantidad, 0);
        contador.textContent = totalItems;
    }
}

// Función para mostrar notificaciones
function mostrarNotificacion(mensaje, tipo = 'info') {
    const notificacion = document.createElement('div');
    notificacion.className = `alert alert-${tipo} alert-dismissible fade show position-fixed`;
    notificacion.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    notificacion.innerHTML = `
        ${mensaje}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(notificacion);
    
    setTimeout(() => {
        if (notificacion.parentNode) {
            notificacion.parentNode.removeChild(notificacion);
        }
    }, 3000);
}

// Función para ver carrito
function verCarrito() {
    window.location.href = 'carrito.html';
}
