# TechMark - Prototipo Fullstack

Este es un prototipo de tienda de tecnología desarrollado como parte de la evaluación 1 de Fullstack 2. El proyecto implementa un sistema de e-commerce completo con múltiples páginas y funcionalidades básicas.

## 🚀 Características Implementadas

### ✅ Navegación Completa
- Menú responsive con logo y enlaces a todas las páginas
- Navegación entre Home, Registro, Login, Productos, Nosotros, Blog, Contacto y Administrador
- Contador de carrito en tiempo real

### ✅ Página Principal (Home)
- Banner atractivo con gradiente
- Listado de productos destacados
- Diseño responsive y moderno
- Integración con Bootstrap 5

### ✅ Sistema de Usuarios
- **Registro**: Formulario con validaciones (nombre, email, contraseña 4-10 caracteres)
- **Login**: Autenticación básica con validaciones
- Validaciones en JavaScript para todos los campos

### ✅ Catálogo de Productos
- Listado dinámico desde arreglo JavaScript
- Búsqueda en tiempo real
- Filtros por precio
- Páginas de detalle de producto
- Productos relacionados
- Botones para agregar al carrito

### ✅ Carrito de Compras
- Funcionalidad básica con localStorage
- Agregar/eliminar productos
- Actualizar cantidades
- Cálculo de totales
- **Sistema de códigos de descuento** (código BENI10 - 10% descuento)
- Simulación de proceso de pago

### ✅ Blog
- Listado de artículos de ejemplo
- Páginas de detalle de artículos
- Newsletter de suscripción
- Artículos relacionados

### ✅ Páginas Informativas
- **Nosotros**: Historia, misión, visión, valores y equipo
- **Contacto**: Formulario con validaciones y información de contacto

### ✅ Panel de Administración
- Dashboard con estadísticas simuladas
- Gestión de usuarios, productos y pedidos
- Gestión de artículos del blog
- Configuración del sistema
- Menú lateral responsive

### ✅ Diseño y UX
- CSS responsivo y atractivo
- Animaciones y transiciones suaves
- Paleta de colores moderna
- Iconos de Bootstrap
- Diseño mobile-first

## 🛠️ Tecnologías Utilizadas

- **HTML5**: Estructura semántica
- **CSS3**: Estilos personalizados y responsive design
- **JavaScript ES6+**: Funcionalidades interactivas
- **Bootstrap 5.3.8**: Framework CSS y componentes
- **LocalStorage**: Persistencia básica de datos

## 📁 Estructura del Proyecto

```
evfullstack1/
├── index.html              # Página principal
├── css/
│   └── estilos.css         # Estilos principales
├── js/
│   ├── main.js            # JavaScript principal
│   ├── productos.js       # Funcionalidad de productos
│   ├── detalle-producto.js # Detalle de productos
│   ├── carrito.js         # Funcionalidad del carrito
│   ├── blog.js            # Funcionalidad del blog
│   └── administrador.js   # Panel de administración
├── pages/
│   ├── registro.html      # Página de registro
│   ├── login.html         # Página de login
│   ├── productos.html     # Catálogo de productos
│   ├── detalle-producto.html # Detalle de producto
│   ├── carrito.html       # Carrito de compras
│   ├── blog.html          # Blog principal
│   ├── detalle-articulo.html # Detalle de artículo
│   ├── contacto.html      # Página de contacto
│   ├── nosotros.html      # Página sobre nosotros
│   └── administrador.html # Panel de administración
├── img/
│   └── placeholder.jpg    # Imagen placeholder
└── README.md              # Este archivo
```

## 🚀 Cómo Usar

1. **Abrir el proyecto**: Simplemente abre `index.html` en tu navegador
2. **Navegar**: Usa el menú para explorar todas las páginas
3. **Probar funcionalidades**:
   - Registrarse y hacer login
   - Explorar productos y agregar al carrito
   - Leer artículos del blog
   - Enviar formulario de contacto
   - Explorar el panel de administración

## 📝 Funcionalidades Implementadas vs. Requeridas

### ✅ Completamente Implementado
- [x] Estructura de carpetas organizadas
- [x] Navegación completa con todos los enlaces
- [x] Página Home con banner y productos
- [x] Formularios de Registro/Login con validaciones
- [x] Página de Productos con arreglo JS
- [x] Carrito con localStorage básico
- [x] Blog con artículos de ejemplo
- [x] Página de Contacto con validaciones
- [x] Panel de Administrador con menú lateral
- [x] CSS responsivo y atractivo
- [x] JavaScript con validaciones y funcionalidades

### 🔄 Funcionalidades Simuladas (Para Futuras Mejoras)
- Base de datos real (usando localStorage)
- Procesamiento de pagos real
- Autenticación de usuarios real
- Gestión de inventario real
- Sistema de notificaciones por email

## 💡 Comentarios del Desarrollador

Este prototipo demuestra un entendimiento completo de:
- Desarrollo frontend con HTML, CSS y JavaScript
- Diseño responsive y UX moderno
- Validaciones de formularios
- Manejo de estado con localStorage
- Estructura de proyecto organizada
- Integración de frameworks CSS (Bootstrap)

**Nota**: Este es un prototipo funcional para demostración. En un entorno de producción se requerirían mejoras como backend real, base de datos, autenticación segura, y procesamiento de pagos.

## 🎯 Próximos Pasos Sugeridos

1. Implementar backend con Node.js/Express
2. Integrar base de datos (MongoDB/PostgreSQL)
3. Añadir autenticación JWT
4. Implementar procesamiento de pagos real
5. Añadir tests unitarios
6. Optimizar para SEO
7. Implementar PWA (Progressive Web App)

---

**Desarrollado por**: [Tu Nombre]  
**Fecha**: Enero 2025  
**Asignatura**: Fullstack 2 - Evaluación 1  
**Marca**: TechMark - Tu tienda de tecnología de confianza
